import jupman
import local


def add(x,y):   
    
    return x + y
    

def sub(x,y):
    return help_func(x,y) 


def help_func(x,y):
    return x - y



# everything after next comment will be discarded

# write here

def f(x):
    return x + 1