

def gimme(x):
    print("It was a %s indeed" % x)
