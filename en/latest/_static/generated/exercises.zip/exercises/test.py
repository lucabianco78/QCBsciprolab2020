"""usage of the IDE"""

a ="###################################"

b = "#this is a comment!"
c = b.center(len(a),"#")

print(a)
print(c)
print(a)

a = dict()

a = a.fromkeys(["1","2","3"],"1")

print(a)