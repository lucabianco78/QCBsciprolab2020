
here you should put exercises, tyipically divided by lessons, i.e.: 

some-topic/
yet-another-topic/

When you build with Sphinx, in directory overlay/_static will appear zips with the contents of these directories:


overlay/_static/some-topic-exercises.zip
overlay/_static/yet-another-topic-exercises.zip



