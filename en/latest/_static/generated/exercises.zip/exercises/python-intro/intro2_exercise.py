
# This exercise is alredy present, so no exercise will be generated from solution

def mul(x,y):
    raise Exeption("WRITE SOMETHING HERE")