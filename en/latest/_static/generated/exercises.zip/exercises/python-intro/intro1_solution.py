
def add(x,y):   
    #jupman-raise
    return x + y
    #/jupman-raise

def sub(x,y):
    return help_func(x,y) 

#jupman-strip
def help_func(x,y):
    return x - y
#/jupman-strip


# everything after next comment will be discarded

# write here

def f(x):
    return x + 1