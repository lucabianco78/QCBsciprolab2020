a = ["ciao", "a", "tutti"]

b = "!!!".join(a)

print(b)

A = "ATACTAACAT"

b = list(A)
print(b)

print(''.join(b))

print(type(input()))

a = input()

print(a)